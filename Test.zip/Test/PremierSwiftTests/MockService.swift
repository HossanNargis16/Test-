//
//  MockService.swift
//  PremierSwiftTests
//
//  Created by MohammadHossan on 07/03/2024.
//  Copyright © 2024 Deliveroo. All rights reserved.
//

import Foundation
@testable import PremierSwift

final class MockService: APIManaging {
    
    var responseFileName = ""
    
    func execute<Value>(_ request: PremierSwift.Request<Value>, completion: @escaping (Result<Value, PremierSwift.APIError>) -> Void) where Value : Decodable {
        
        let bundle = Bundle(for: MockService.self)
        guard let url = bundle.url(forResource: responseFileName, withExtension:"json"),
              let data = try? Data(contentsOf: url),
              let output = try? JSONDecoder().decode(Value.self, from: data)
        else {
            completion(.failure(.parsingError))
            return
        }
        completion(.success(output))
    }
}
