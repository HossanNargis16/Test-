//
//  MovieDataTest.swift
//  PremierSwiftTests
//
//  Created by MohammadHossan on 07/03/2024.
//  Copyright © 2024 Deliveroo. All rights reserved.
//

import XCTest
@testable import PremierSwift

final class MovieDataTest: XCTestCase {
    
    var mockService: MockService!
    var viewModel: MoviesViewModel!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        mockService = MockService()
        viewModel = MoviesViewModel(apiManager: mockService)
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        mockService = nil
        viewModel =  nil
    }
    
    func testTotal_movieCount_withSuccess_case() {
        
        //GIVEN
        let expectation = expectation(description: "Wait for async code to complete")
        mockService.responseFileName = "MovieSuccessResponse"
        viewModel.fetchData()
        //WHEN
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            expectation.fulfill()
        }
        //THEN
        let resultCount = self.viewModel.state.movies.count
        XCTAssertNotNil(resultCount)
        XCTAssertEqual(resultCount ,20, "Total record is  matched")
        wait(for: [expectation], timeout: 2.0)
    }
    
    func testMovie_First_Title_withSuccess() {
        
        //GIVEN
        let expectation = expectation(description: "Wait for async code to complete")
        mockService.responseFileName = "MovieSuccessResponse"
        viewModel.fetchData()
        //WHEN
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            expectation.fulfill()
        }
        let title = self.viewModel.state.movies.first?.title
        //THEN
        XCTAssertEqual(title ,"The Shawshank Redemption", "Title is matched")
        wait(for: [expectation], timeout: 2.0)
    }
    
    func testTotal_movieCount_withFailure_Case() {
        
        //GIVEN
        let expectation = expectation(description: "Wait for async code to complete")
        mockService.responseFileName = "MovieFailureResponse"
        viewModel.fetchData()
        //WHEN
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            expectation.fulfill()
        }
        let resultCount = self.viewModel.state.movies.count
        //THEN
        XCTAssertNotNil(resultCount)
        XCTAssertEqual(resultCount ,0, "Total record is  emapty")
        wait(for: [expectation], timeout: 2.0)
    }
    
    func testSearcMovie_success_withLatter_The_God() {
        
        //GIVEN
        let expectation = expectation(description: "Wait for async code to complete")
        mockService.responseFileName = "MovieSuccessResponse"
        viewModel.fetchData()
        //WHEN
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            expectation.fulfill()
        }
        //THEN
        self.viewModel.updateSearchController(searchBarText: "The God")
        XCTAssertEqual(self.viewModel.filteredMovie.count, 2)
        wait(for: [expectation], timeout: 2.0)
    }
    
    func testSearcMovie_success_withLatter_You() {
        
        //GIVEN
        let expectation = expectation(description: "Wait for async code to complete")
        mockService.responseFileName = "MovieSuccessResponse"
        viewModel.fetchData()
        
        //WHEN
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            expectation.fulfill()
        }
        //THEN
        self.viewModel.updateSearchController(searchBarText: "You")
        XCTAssertEqual(self.viewModel.filteredMovie.count, 1)
        wait(for: [expectation], timeout: 2.0)
    }
    
    func testSearcBar_isEmpty() {
        
        //GIVEN
        let expectation = expectation(description: "Wait for async code to complete")
        mockService.responseFileName = "MovieSuccessResponse"
        viewModel.fetchData()
        //WHEN
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            expectation.fulfill()
        }
        //THEN
        self.viewModel.updateSearchController(searchBarText: "")
        XCTAssertEqual(self.viewModel.state.movies.count, 20)
        wait(for: [expectation], timeout: 2.0)
    }
}
