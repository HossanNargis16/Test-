import UIKit

class SimilarMovieViewController: UIViewController, UICollectionViewDelegate {
    
    private let viewModel: MoviesDetailsViewModel
    
    init(viewModel: MoviesDetailsViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    // MARK: - Creating UI Properties.
    lazy var titleLable: UILabel = {
        let titleLable = UILabel()
        titleLable.translatesAutoresizingMaskIntoConstraints = false
        titleLable.font = UIFont.systemFont(ofSize: 18)
        titleLable.font = UIFont.boldSystemFont(ofSize: titleLable.font.pointSize)
        titleLable.text = "Similar movies"
        return titleLable
    }()
    lazy var viewAllLable: UILabel = {
        let viewAllLable = UILabel()
        viewAllLable.translatesAutoresizingMaskIntoConstraints = false
        viewAllLable.font = UIFont.systemFont(ofSize: 18)
        viewAllLable.text = "View all"
        viewAllLable.textColor = .purple
        return viewAllLable
    }()
    let rightImageView: UIImageView = {
        let rightImageView = UIImageView()
        rightImageView.image =  UIImage(named: "ArrowRight")
        rightImageView.contentMode = .right
        rightImageView.translatesAutoresizingMaskIntoConstraints = false
        rightImageView.tintColor = .purple
        return rightImageView
    }()
    
    let stackview: UIStackView = {
        let stackview = UIStackView()
        stackview.axis = .horizontal
        stackview.spacing = 10
        stackview.translatesAutoresizingMaskIntoConstraints = false
        return stackview
    }()
    
    // MARK: - Colletion view UI Components.
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: 100, height: 200)
        let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collection.translatesAutoresizingMaskIntoConstraints = false
        collection.dataSource = self
        collection.delegate = self
        collection.register(SimilarMovieCell.self, forCellWithReuseIdentifier: SimilarMovieCell.identifier)
        collection.backgroundColor = .clear
        return collection
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        self.viewModel.updatedState = { [weak self] in
            DispatchQueue.main.async {
                self?.collectionView.reloadData()
            }
        }
        viewModel.fetchSimilarMovie()
    }
    // MARK: - Adding views Hierarchy with Constrains.
    private func setUpUI() {
        view.addSubview(stackview)
        stackview.dm_addArrangedSubviews(titleLable, viewAllLable, rightImageView)
        view.dm_addSubviews(collectionView)
        
        let safeArea = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            
            stackview.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 8.0),
            stackview.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: -8.0),
            stackview.topAnchor.constraint(equalTo: safeArea.topAnchor, constant: 8.0),
            rightImageView.widthAnchor.constraint(equalTo: rightImageView.heightAnchor),
            collectionView.topAnchor.constraint(equalTo: stackview.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),
            collectionView.heightAnchor.constraint(equalToConstant: view.frame.width/2)
        ])
        viewAllLable.setContentHuggingPriority(.required, for: .horizontal)
    }
}
// MARK: - UICollectionViewDataSource.
extension SimilarMovieViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/2.5, height: collectionView.frame.width/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let items = viewModel.moviePage.count
        return items
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SimilarMovieCell.identifier, for: indexPath) as? SimilarMovieCell
        
        let listMovie = viewModel.moviePage[indexPath.row]
        cell?.configure(movie: listMovie)
        return cell ?? SimilarMovieCell()
    }
}
