import UIKit

final class MovieDetailsDisplayViewController: UIViewController {
    
    let movieDetails: MovieDetails
    let viewModel: MoviesDetailsViewModel
    
    init(movieDetails: MovieDetails, viewModel: MoviesDetailsViewModel) {
        self.movieDetails = movieDetails
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    let imgView = UIImageView()
    let titleLabel = UILabel()
    let overviewLabel = UILabel()
    let contentStackView = UIStackView()
    let scrollView = UIScrollView()
    let addChildView = UIView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        arragedViews()
        configureMovieCell(movie: movieDetails)
        addSimiliarMovie()
    }
    
    // MARK: Configure View properties.
    private func setUpUI() {
        
        imgView.contentMode = .scaleAspectFill
        imgView.clipsToBounds = true
        
        titleLabel.font = UIFont.Heading.medium
        titleLabel.textColor = UIColor.Text.charcoal
        titleLabel.numberOfLines = 0
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.setContentHuggingPriority(.required, for: .vertical)
        
        overviewLabel.font = UIFont.Body.small
        overviewLabel.textColor = UIColor.Text.grey
        overviewLabel.numberOfLines = 0
        overviewLabel.lineBreakMode = .byWordWrapping
        
        contentStackView.axis = .vertical
        contentStackView.spacing = 24
        contentStackView.setCustomSpacing(8, after: titleLabel)
        contentStackView.translatesAutoresizingMaskIntoConstraints = false
        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    // MARK: Arrange views.
    private func arragedViews() {
        
        scrollView.addSubview(contentStackView)
        contentStackView.dm_addArrangedSubviews(imgView)
        contentStackView.dm_addArrangedSubviews(titleLabel)
        contentStackView.dm_addArrangedSubviews(overviewLabel)
        view.addSubview(scrollView)
    }
    
    // MARK: configure movie details cell.
    private func configureMovieCell(movie: MovieDetails) {
        
        imgView.dm_setImage(backdropPath: movie.backdropPath)
        titleLabel.text = movie.title
        overviewLabel.text = movieDetails.overview
    }
    
    // MARK: Add child view controller content.
    private func addSimiliarMovie() {
        
        addChildView.backgroundColor = .clear
        addChildView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(addChildView)
        
        // so we don't have to type so much
        let safeAreaLayoutGuide = view.safeAreaLayoutGuide
        let contentLayoutGuide = scrollView.contentLayoutGuide
        let frameLayoutGuide = scrollView.frameLayoutGuide
        
        NSLayoutConstraint.activate([
            
            scrollView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: addChildView.topAnchor, constant: -20.0),
            
            contentStackView.topAnchor.constraint(equalTo: contentLayoutGuide.topAnchor, constant: 20.0),
            contentStackView.leadingAnchor.constraint(equalTo: contentLayoutGuide.leadingAnchor, constant: 20.0),
            contentStackView.trailingAnchor.constraint(equalTo: contentLayoutGuide.trailingAnchor, constant: -20.0),
            contentStackView.bottomAnchor.constraint(equalTo: contentLayoutGuide.bottomAnchor, constant: -20.0),
            contentStackView.widthAnchor.constraint(equalTo: frameLayoutGuide.widthAnchor, constant: -40.0),
            
            // image view needs height
            imgView.heightAnchor.constraint(equalTo: imgView.widthAnchor, multiplier: 1),
            addChildView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 20.0),
            addChildView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -20.0),
            addChildView.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -20.0),
            
            // height of the child content
            addChildView.heightAnchor.constraint(equalToConstant: 180.0),
            
        ])
        
        let similarVC = SimilarMovieViewController(viewModel: viewModel)
        addChild(similarVC)
        // safely unwrap MySimilarViewController's view
        guard let similarView = similarVC.view else { return }
        similarView.translatesAutoresizingMaskIntoConstraints = false
        addChildView.addSubview(similarView)
        NSLayoutConstraint.activate([
            similarView.topAnchor.constraint(equalTo: addChildView.topAnchor),
            similarView.leadingAnchor.constraint(equalTo: addChildView.leadingAnchor),
            similarView.trailingAnchor.constraint(equalTo: addChildView.trailingAnchor),
            similarView.bottomAnchor.constraint(equalTo: addChildView.bottomAnchor),
        ])
        similarVC.didMove(toParent: self)
    }
}
