//

import UIKit

class SimilarMovieCell: UICollectionViewCell {
    
    static let identifier = "SimilarMovieCell"
    let columnSpacing: CGFloat = 16
    let posterSize = CGSize(width: 92, height: 134)
    
    let movieImage = UIImageView()
    let tagView = TagView()
    let titleLabel = UILabel()
    
    let childStackView = UIStackView()
    let containerStackView = UIStackView()
    
    private func commonInit() {
        
        titleLabel.font = UIFont.systemFont(ofSize: 15)
        titleLabel.textColor = UIColor.Text.charcoal
        titleLabel.numberOfLines = 0
        titleLabel.lineBreakMode = .byWordWrapping
        
        movieImage.contentMode = .scaleAspectFit
        movieImage.layer.cornerRadius = 8
        movieImage.layer.masksToBounds = true
        
        childStackView.spacing = 10
        childStackView.alignment = .leading
        childStackView.axis = .vertical
        
        containerStackView.spacing = columnSpacing
        containerStackView.alignment = .top
        containerStackView.translatesAutoresizingMaskIntoConstraints = false
        
        setupViewsHierarchy()
        setupConstraints()
    }
    
    func setupViewsHierarchy() {
        contentView.addSubview(containerStackView)
        childStackView.dm_addArrangedSubviews(movieImage)
        childStackView.dm_addArrangedSubviews(titleLabel)
        childStackView.dm_addArrangedSubviews(tagView)
        containerStackView.dm_addArrangedSubviews(childStackView)
    }
    
    //Constraints
    func setupConstraints() {
        
        NSLayoutConstraint.activate([
            containerStackView.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            containerStackView.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
            containerStackView.topAnchor.constraint(equalTo: contentView.layoutMarginsGuide.topAnchor),
            containerStackView.bottomAnchor.constraint(equalTo: contentView.layoutMarginsGuide.bottomAnchor),
            
            movieImage.widthAnchor.constraint(equalToConstant: posterSize.width),
            movieImage.heightAnchor.constraint(equalToConstant: posterSize.height),
            
            titleLabel.topAnchor.constraint(equalTo: movieImage.bottomAnchor),
            tagView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor)
            
        ])
    }
    
    func configure(movie: Movie) {
        commonInit()
        
        titleLabel.text = movie.title
        tagView.configure(.rating(value: movie.voteAverage))
        
        if let path = movie.posterPath {
            movieImage.dm_setImage(posterPath: path)
        } else {
            movieImage.image = nil
        }
    }
}
