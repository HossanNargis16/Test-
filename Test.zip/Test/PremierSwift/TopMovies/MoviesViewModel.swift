import Foundation
import UIKit

enum MoviesViewModelState {
    case loading
    case loaded([Movie])
    case error

    var movies: [Movie] {
        switch self {
        case .loaded(let movies):
            return movies
        case .loading, .error:
            return []
        }
    }
}

final class MoviesViewModel {

    private let apiManager: APIManaging
    var filteredMovie: [Movie] = []

    init(apiManager: APIManaging = APIManager()) {
        self.apiManager = apiManager
    }

    var updatedState: (() -> Void)?

    var state: MoviesViewModelState = .loading {
        didSet {
            updatedState?()
        }
    }

    func fetchData() {
        apiManager.execute(Movie.topRated) { [weak self] result in
            switch result {
            case .success(let page):
                self?.state = .loaded(page.results)
            case .failure:
                self?.state = .error
            }
        }
    }
}

// MARK: - Search function.
extension MoviesViewModel {
    
    public func inSearchMode(_ searchController: UISearchController) -> Bool {
        
        let isActive = searchController.isActive
        let searchText = searchController.searchBar.text ?? ""
        return isActive && !searchText.isEmpty
    }
    
    public func updateSearchController(searchBarText: String?) {
        
        self.filteredMovie = state.movies
        if let searchText = searchBarText?.lowercased() {
            guard !searchText.isEmpty else { return }
            self.filteredMovie = self.filteredMovie.filter({ $0.title.lowercased().contains(searchText) })
        }
    }
}
